# Fintrack Pro v2

Pencatatan keuangan dengan React + Vite + Tailwind.
